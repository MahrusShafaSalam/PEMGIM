#pragma once

const int WIDTH = 800;
const int HEIGHT = 400;

const double PI = 3.14159265;

enum GameState { MENU, GAME, GAMEOVER };

enum ObjectID { BIRD, TUBE };